<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tas"
?>

<!-- Wie nutze ich diese Datei?
<html>
<body>

<div class="menu">
<//?php require 'dbinclude.php';?//>
</div>

<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>

</body>
</html> https://www.w3schools.com/php/php_includes.asp!--> 